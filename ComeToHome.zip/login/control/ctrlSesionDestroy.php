<?php
require_once('../Modelo/ModeloLogin.php');

$login = new Login();
$login->logOut();
